import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;

public class Client {
    private static File selectedFile = null;
    private static JLabel jlStatus;
    private static JProgressBar progressBar;

    public static void main(String[] args) {
        JFrame jFrame = new JFrame("File Sender");
        jFrame.setSize(450, 300);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));
        panel.setBackground(Color.WHITE);

        JLabel jlTitle = new JLabel("Select a File to Send");
        jlTitle.setFont(new Font("Arial", Font.BOLD, 22)); 
        jlTitle.setForeground(Color.BLACK);
        jlTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton jbSelectFile = new JButton("Choose File");
        JButton jbSendFile = new JButton("Send File");
        jbSendFile.setEnabled(false);

        styleButton(jbSelectFile);
        styleButton(jbSendFile);

        jlStatus = new JLabel("No file selected");
        jlStatus.setForeground(Color.BLACK);
        jlStatus.setAlignmentX(Component.CENTER_ALIGNMENT);

        progressBar = new JProgressBar(0, 100);
        progressBar.setVisible(false);
        progressBar.setStringPainted(true);

        jbSelectFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser jFileChooser = new JFileChooser();
                int returnValue = jFileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    selectedFile = jFileChooser.getSelectedFile();
                    jlStatus.setText("Selected: " + selectedFile.getName());
                    jbSendFile.setEnabled(true);
                }
            }
        });

        jbSendFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedFile != null) {
                    sendFile(selectedFile);
                }
            }
        });

        panel.add(jlTitle);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(jbSelectFile);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(jlStatus);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(jbSendFile);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(progressBar);

        jFrame.add(panel, BorderLayout.CENTER);
        jFrame.setVisible(true);
    }

    private static void styleButton(JButton button) {
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
    }

    private static void sendFile(File file) {
        new Thread(() -> {
            try (Socket socket = new Socket("192.168.29.125", 1235);
                 DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                 FileInputStream fis = new FileInputStream(file)) {
                
                byte[] fileNameBytes = file.getName().getBytes();
                dos.writeInt(fileNameBytes.length);
                dos.write(fileNameBytes);
                dos.writeLong(file.length());

                progressBar.setVisible(true);
                byte[] buffer = new byte[4096];
                int bytesRead;
                long totalBytesRead = 0;
                long fileSize = file.length();
                
                while ((bytesRead = fis.read(buffer)) > 0) {
                    dos.write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                    int progress = (int) ((totalBytesRead * 100) / fileSize);
                    progressBar.setValue(progress);
                }
                
                JOptionPane.showMessageDialog(null, "File Sent Successfully!");
                jlStatus.setText("File Sent: " + file.getName());
            } catch (Exception e) {
                e.printStackTrace();
                jlStatus.setText("Error sending file!");
            }
        }).start();
    }
}
