public class MyFile {
    private int id;
    private String name;
    private byte[] data;
    private String fileExtension;

    public MyFile(int id, String name, byte[] data, String fileExtension) {
        this.id = id;
        this.name = name;
        this.data = data;
        this.fileExtension = fileExtension;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public byte[] getdata() {  // Fixed method name
        return data;
    }

    public String getFileExtension() {
        return fileExtension;
    }

    // Optional: Override toString() for debugging
    @Override
    public String toString() {
        return "MyFile{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", fileExtension='" + fileExtension + '\'' +
                ", dataLength=" + (data != null ? data.length : 0) + " bytes" +
                '}';
    }
}
