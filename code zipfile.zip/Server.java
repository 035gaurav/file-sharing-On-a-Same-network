import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {
    static ArrayList<MyFile> myFiles = new ArrayList<>();
    static int fileId = 0;

    public static void main(String[] args) {
        JFrame jFrame = new JFrame("Gaurav Server");
        jFrame.setSize(400, 400);
        jFrame.setLayout(new BoxLayout(jFrame.getContentPane(), BoxLayout.Y_AXIS));
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));

        JScrollPane jScrollPane = new JScrollPane(jPanel);
        jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        JLabel jlTitle = new JLabel("Gaurav File Receiver");
        jlTitle.setFont(new Font("Arial", Font.BOLD, 25));
        jlTitle.setBorder(new EmptyBorder(20, 0, 10, 0));
        jlTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        jFrame.add(jlTitle);
        jFrame.add(jScrollPane);
        jFrame.setVisible(true);

        try (ServerSocket serverSocket = new ServerSocket(1235)) {
            System.out.println("Server is listening on port 1234...");

            while (true) {
                Socket socket = serverSocket.accept();
                int currentFileId;
                synchronized (Server.class) {
                    currentFileId = fileId++;
                }
                new Thread(() -> handleClient(socket, jPanel, jFrame, currentFileId)).start();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void handleClient(Socket socket, JPanel jPanel, JFrame jFrame, int fileId) {
        try (DataInputStream dataInputStream = new DataInputStream(socket.getInputStream())) {
            int fileNameLength = dataInputStream.readInt();
            if (fileNameLength > 0) {
                byte[] fileNameBytes = new byte[fileNameLength];
                dataInputStream.readFully(fileNameBytes);
                String fileName = new String(fileNameBytes);

                long fileContentLength = dataInputStream.readLong();

                // Save file to disk directly
                File fileOnDisk = new File(fileName);
                try (FileOutputStream fileOutputStream = new FileOutputStream(fileOnDisk)) {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while (fileContentLength > 0 &&
                            (bytesRead = dataInputStream.read(buffer, 0, (int) Math.min(buffer.length, fileContentLength))) != -1) {
                        fileOutputStream.write(buffer, 0, bytesRead);
                        fileContentLength -= bytesRead;
                    }
                }

                // For download feature: only store file data in memory if it's small
                byte[] fileContentBytes = null;
                if (fileOnDisk.length() <= 100 * 1024 * 1024) { // 100MB
                    fileContentBytes = new byte[(int) fileOnDisk.length()];
                    try (FileInputStream fis = new FileInputStream(fileOnDisk)) {
                        fis.read(fileContentBytes);
                    }
                }

                String fileExtension = fileName.contains(".") ? fileName.substring(fileName.lastIndexOf(".") + 1) : "";

                MyFile receivedFile = new MyFile(fileId, fileName, fileContentBytes, fileExtension);
                myFiles.add(receivedFile);

                SwingUtilities.invokeLater(() -> {
                    JPanel filePanel = new JPanel();
                    filePanel.setLayout(new BoxLayout(filePanel, BoxLayout.Y_AXIS));

                    JLabel jlFile = new JLabel("Received: " + fileName);
                    JButton downloadButton = new JButton("Download");

                    downloadButton.addActionListener((ActionEvent e) -> {
                        downloadFile(receivedFile);
                    });

                    filePanel.add(jlFile);
                    filePanel.add(downloadButton);

                    jPanel.add(filePanel);
                    jFrame.validate();
                });

                System.out.println("File received: " + fileName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void downloadFile(MyFile myFile) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save File");
        fileChooser.setSelectedFile(new File(myFile.getName()));

        int userSelection = fileChooser.showSaveDialog(null);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File destinationFile = fileChooser.getSelectedFile();
            File sourceFile = new File(myFile.getName()); 

            try (InputStream in = new FileInputStream(sourceFile);
                 OutputStream out = new FileOutputStream(destinationFile)) {

                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = in.read(buffer)) > 0) {
                    out.write(buffer, 0, bytesRead);
                }

                JOptionPane.showMessageDialog(null, "File downloaded successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving file!", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }
}
